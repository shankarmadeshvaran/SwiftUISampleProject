//
//  ContentView.swift
//  ComplexSwiftUI
//
//  Created by User on 07/06/19.
//  Copyright © 2019 Heptagon. All rights reserved.
//

import SwiftUI

struct ContentView : View {
    var topics: [Topic] = []
    @State var showVideoTopics = false
    
    var body: some View {
        NavigationView {
            Toggle(isOn: $showVideoTopics, label: {
                Text("Include Video Topics").bold()
                }).padding(20)
            List {
                if showVideoTopics {
                    ForEach(Topic.videoTopics.identified(by: \.id)) { videoTopic in
                        TopicRow(topic: videoTopic)
                    }
                }
                ForEach(Topic.tutorialTopics.identified(by: \.id)) { tutorialTopic in
                    TopicRow(topic: tutorialTopic)
                }
            } .navigationBarTitle(Text("SwiftUI Topics")).font(.largeTitle)
        }
    }
}

#if DEBUG
struct ContentView_Previews : PreviewProvider {
    static var previews: some View {
        ContentView(topics: testTopics)
    }
}
#endif


