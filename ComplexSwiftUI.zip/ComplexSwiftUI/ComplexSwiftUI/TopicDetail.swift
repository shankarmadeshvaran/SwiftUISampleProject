//
//  TopicDetail.swift
//  ComplexSwiftUI
//
//  Created by User on 10/06/19.
//  Copyright © 2019 Heptagon. All rights reserved.
//

import SwiftUI

struct TopicDetail : View {
    let topic: Topic
    
    var body: some View {
        VStack(alignment: .leading) {
        Text(topic.description).lineLimit(nil)
            .font(.headline)
        Text(topic.externalLink)
            .lineLimit(nil)
        }
    }
}

#if DEBUG
struct TopicDetail_Previews : PreviewProvider {
    static var previews: some View {
        TopicDetail(topic: testTopics[0])
    }
}
#endif
